# Reproducing the eGlu performance audit

Audit revision: 75fcca22f0ae46e36cc60360f000cdf620449abc.

This standalone Swift executable imports the unmodified PadCore package. No product code was changed. Fixtures are synthetic and contain no user data. Build and data files are outside the repository.

## Run

1. Set the PadCore dependency path in Package.swift to your checkout's PadCore directory.
2. Set the fixture root in Sources/Audit/Audit.swift to an empty writable directory.
3. Run `swift run -c release Audit`. Seeding and pruning 10,000 pages may each take about 30 seconds on the audited machine.
4. For snapshot-only work, run `AUDIT_MODE=snapshots swift run -c release Audit`.

To check the missing-index hypothesis, copy the completed 10,000-page SQLite fixture using SQLite's backup API, then execute only on the COPY:

```sql
CREATE INDEX audit_visits_by_page_time ON visits(space, page, time DESC);
```

Run `AUDIT_REOPEN=/absolute/path/to/copy.sqlite .build/release/Audit`. Run the same command against the baseline for the comparison. This mode uses one-month retention, with no expired visits. The default initial benchmark uses forever retention, also with no expired visits.

## Evidence files

- benchmark.log: original release build, 10,000-page seed/search/prune/open measurements. A subsequent 50,000-page seed was stopped to bound the audit; no 50,000-page measurement is claimed. The final runner defaults to 10,000 pages only.
- repeat-history.log: baseline, reopened fixture, one-month retention.
- indexed-history.log: copied fixture with the extra composite index, same production prune method and one-month retention.
- snapshots.log: directory scan medians of 25 invalidations; synchronous consumption behind 20 queued 1 MB writes. The queued-write test is a stress scenario, not a typical-navigation latency claim.
- query-plans.txt: EXPLAIN QUERY PLAN and 100-execution averages from Python SQLite 3.51.0, using the same fixtures.
- history-sample.txt: macOS sample capture during the stopped large-history seed. Most active samples are inside HistoryStore.refresh's SQLite queries. This is not an Instruments trace or a profile of the running browser.

The first snapshot run used fresh directories with exactly 100, 1,000 and 4,000 files. The delivered runner adds a UUID to each directory so subsequent runs do not accumulate extra files.

Environment: ARM64 macOS 26.6.2 VM, 12 CPUs, 16 GiB RAM, Swift 6.3.3, release optimization. Timings are machine- and workload-specific. Search timings are medians of seven warm calls, not cold disk measurements. History fixtures contain one visit per unique page in one space, with similar titles/descriptions and no saved search terms.

## Enriched audit

The original logs above are preserved, not replaced by new measurements.

### Main: sync and history scaling

Update the absolute fixture path in `Sources/Audit/Enrichment.swift` as well as the paths described above, then run:

```sh
AUDIT_MODE=enrich swift run -c release Audit
```

`enrichment.log` records nine-call medians for one bookmark rename in 100, 1,000 and 10,000-bookmark workspaces. A single space is joined to sync. All bookmarks are flat, with no pinned tabs or extensions. Each iteration starts from the same stamped mirror; an assertion checks that exactly one record changed. The measured pipeline is `hasSyncableChanges` + `records` + `stamp` + `settleSpaces`. CloudKit submission, disk persistence and SwiftUI rendering are not included. The first timing column includes `hasSyncableChanges`; component medians need not sum to the total median.

The same mode creates new 1,000 and 3,000-page history fixtures, measures three maintenance calls per fixture and seven search calls per query. These are additional scale points, not replacements for the original 10,000-page observations. UUIDs are fresh on each run; exact query distributions and filesystem/SQLite cache state can change absolute timings. The original reopened-history comparison requires freshly generated fixtures so one-month retention still expires zero rows.

### Main: extension scanner

```sh
AUDIT_MODE=extensions swift run -c release Audit
```

`extension-scan.log` measures the unmodified `ExtensionScan.uses` on repeated benign JavaScript, with an empty missing-API set. It checks the result is empty. Three-call medians isolate tokenization/scanning overhead. They do not measure ZIP extraction, a real extension, WebKit startup or memory allocations. Source construction is outside the timed interval.

### PR #170: bookmark-bar lookup cost

The archive includes `pr170/Package.swift` and `pr170/Sources/BarAudit/main.swift`, but not the copied product source or build products. Obtain the exact audited PadCore version using a local repository with the PR commit fetched:

```sh
git -C /path/to/eGlu fetch origin pull/170/head
# The fetched PR may have advanced. Use the pinned audit commit below.
git -C /path/to/eGlu archive 551622df68580b17dba56dfb9e965e1010598ed1 PadCore | tar -x -C pr170
swift run --package-path pr170 -c release BarAudit
```

`pr170-benchmark.log` records three-call medians. The fixture has 100, 1,000 or 3,000 flat bar rows and 100 open, bookmark-linked tabs. It compares calling `space.barTabs[item.id]` for every row with computing the same dictionary once per pass, then indexing it. Both paths assert the same 100 matches. This is a component benchmark of the iPad row lookup expression, not a SwiftUI render benchmark, a Mac benchmark of its already-hoisted parent lookup, or a measurement of the merged app. No PR was checked out over main and no product source was modified.

## Scope and interpretation

- Baseline source is main at `75fcca22f0ae46e36cc60360f000cdf620449abc`.
- Open PRs reviewed: #170, #169, #168, #167, #166 and #97. #168 was compared with its base, #167, not counted as an independent copy of that fix.
- No real app UI profiling, Instruments trace, real-user data, network/CloudKit timing, iOS device measurement, full app build or test suite was run for this audit.
- Reproduction uses macOS and Swift because the original runner imports Darwin. Benchmark package builds passed in release mode.
- Assertions validate fixture shape and key results, not the correctness of the entire product.
