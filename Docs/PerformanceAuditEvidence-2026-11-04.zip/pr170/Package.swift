// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "BarAudit", platforms: [.macOS(.v14)], dependencies: [.package(path: "PadCore")], targets: [.executableTarget(name: "BarAudit", dependencies: [.product(name: "PadCore", package: "PadCore")])])
