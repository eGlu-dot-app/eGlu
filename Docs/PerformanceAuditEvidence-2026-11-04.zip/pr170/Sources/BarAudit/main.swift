import Foundation
import PadCore

func measure(_ body: () -> Int) -> Double {
    var samples: [Double] = []
    for _ in 0..<3 {
        let start = DispatchTime.now().uptimeNanoseconds
        precondition(body() == 100)
        samples.append(Double(DispatchTime.now().uptimeNanoseconds - start) / 1_000_000)
    }
    return samples.sorted()[1]
}
for count in [100, 1000, 3000] {
    let leaves = (0..<count).map { Bookmark(title: "Link \($0)", url: URL(string: "https://example.com/\($0)")!) }
    let tabs = leaves.prefix(100).map { bookmark in
        var tab = TabRecord(url: bookmark.url)
        tab.bookmark = bookmark.id
        return tab
    }
    let space = Space(name: "Audit", symbol: "globe", tabs: tabs, bookmarks: [Bookmark(folder: "Bookmarks bar", children: leaves)])
    precondition(space.barTabs.count == 100)
    let perRow = measure {
        var found = 0
        for item in leaves { if space.barTabs[item.id] != nil { found += 1 } }
        return found
    }
    let hoisted = measure {
        let map = space.barTabs
        return leaves.reduce(0) { $0 + (map[$1.id] == nil ? 0 : 1) }
    }
    print("\(count) bar rows, 100 open tabs, median n3: per-row map=\(perRow) ms; hoisted map=\(hoisted) ms")
}
