// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "PerformanceAudit", platforms: [.macOS(.v14)], dependencies: [.package(path: "/Users/devin/repos/eGlu/PadCore")], targets: [.executableTarget(name: "Audit", dependencies: [.product(name: "PadCore", package: "PadCore")])])
