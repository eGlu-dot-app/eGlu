import Foundation
import PadCore
import Darwin

func ms(_ start: UInt64) -> Double { Double(DispatchTime.now().uptimeNanoseconds - start) / 1_000_000 }
func emit(_ name: String, _ value: Double) { print("\(name): \(String(format: "%.3f", value)) ms"); fflush(stdout) }

@main struct Audit {
    static func main() async throws {
        if ProcessInfo.processInfo.environment["AUDIT_MODE"] == "extensions" {
            extensionScan()
            return
        }
        if ProcessInfo.processInfo.environment["AUDIT_MODE"] == "enrich" {
            try await enrich()
            return
        }
        let root = URL(fileURLWithPath: "/Users/devin/performance-audit/fixtures", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let now = Date()
        let space = UUID()
        if let path = ProcessInfo.processInfo.environment["AUDIT_REOPEN"] {
            let store = try HistoryStore(url: URL(fileURLWithPath: path))
            let t = DispatchTime.now().uptimeNanoseconds
            try await store.prune(keeping: .month, now: now)
            emit("reopened prune (zero expired)", ms(t))
            return
        }
        let counts = ProcessInfo.processInfo.environment["AUDIT_MODE"] == "snapshots" ? [] : [10_000]
        for count in counts {
            let file = root.appendingPathComponent("history-\(count)-\(UUID()).sqlite")
            let store = try HistoryStore(url: file)
            let visits = (0..<count).map { i in
                HistoryVisit(space: space, url: URL(string: "https://example.com/article/\(i)")!,
                             title: "Design systems research article \(i)", summary: "A synthetic description about typography, layouts and components.",
                             time: now.addingTimeInterval(-Double(i % 1000)), device: "audit", kind: .link)
            }
            var t = DispatchTime.now().uptimeNanoseconds
            try await store.merge(visits, now: now)
            emit("seed \(count) pages", ms(t))
            for word in ["", "d", "de", "design", "unmatchedword"] {
                var times: [Double] = []
                for _ in 0..<7 {
                    t = DispatchTime.now().uptimeNanoseconds
                    let result = try await store.search(space: space, query: HistoryQuery(words: word), limit: 12)
                    times.append(ms(t))
                    precondition(result.count <= 12)
                }
                emit("search \(count) pages '\(word)' median", times.sorted()[3])
            }
            t = DispatchTime.now().uptimeNanoseconds
            try await store.prune(keeping: .forever, now: now)
            emit("prune \(count) pages (zero expired)", ms(t))
            t = DispatchTime.now().uptimeNanoseconds
            let reopened = try HistoryStore(url: file)
            emit("open \(count) visits", ms(t))
            _ = reopened.latestWhenOpened
        }
        for count in [100, 1000, 4000] {
            let folder = root.appendingPathComponent("snapshots-\(count)-\(UUID())", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            for _ in 0..<count {
                try Data([1]).write(to: folder.appendingPathComponent("\(space.uuidString).\(UUID().uuidString).state"))
            }
            let files = PageSnapshotFiles(folder: folder)
            var times: [Double] = []
            for _ in 0..<25 {
                let t = DispatchTime.now().uptimeNanoseconds
                files.invalidate(UUID())
                times.append(ms(t))
            }
            emit("invalidate among \(count) snapshot files median", times.sorted()[12])
            let token = files.token(for: UUID(), in: space)
            let t = DispatchTime.now().uptimeNanoseconds
            for _ in 0..<20 { files.save(Data(repeating: 1, count: 1_000_000), kind: .state, url: nil, using: token) }
            let began = DispatchTime.now().uptimeNanoseconds
            _ = files.takeState(url: nil, using: token)
            emit("takeState waits behind 20 queued 1MB writes", ms(began))
            emit("queued writes plus takeState total", ms(t))
        }
    }
}
