import Foundation
import PadCore

func enrich() async throws {
    let now = Date()
    for count in [100, 1000, 10000] {
        var space = Space(name: "Audit", symbol: "globe", bookmarks: (0..<count).map {
            Bookmark(title: "Bookmark \($0)", url: URL(string: "https://example.com/\($0)")!)
        })
        space.cloudID = UUID()
        let original = Workspace(spaces: [space])
        var clock = SyncClock(device: "audit")
        let mirror = SyncPlan.stamp(SyncPlan.records(of: original, keeping: SyncMirror()), over: SyncMirror(), clock: &clock, now: now).mirror
        space.bookmarks[count / 2].title = "One renamed bookmark"
        let changed = Workspace(spaces: [space])
        var records: [Double] = [], stamps: [Double] = [], totals: [Double] = []
        for _ in 0..<9 {
            var clock = clock
            let t = DispatchTime.now().uptimeNanoseconds
            precondition(SyncPlan.hasSyncableChanges(from: original, to: changed))
            let next = SyncPlan.records(of: changed, keeping: mirror)
            let mid = DispatchTime.now().uptimeNanoseconds
            var stamped = SyncPlan.stamp(next, over: mirror, clock: &clock, now: now)
            precondition(stamped.changed.count == 1)
            precondition(stamped.mirror.settleSpaces().isEmpty)
            records.append(Double(mid - t) / 1_000_000)
            stamps.append(ms(mid)); totals.append(ms(t))
        }
        emit("sync \(count) bookmarks records median n9", records.sorted()[4])
        emit("sync \(count) bookmarks stamp+settle median n9", stamps.sorted()[4])
        emit("sync \(count) bookmarks full pipeline median n9", totals.sorted()[4])
    }
    for count in [1000, 3000] {
        let file = URL(fileURLWithPath: "/Users/devin/performance-audit/fixtures/enrich-\(count)-\(UUID()).sqlite")
        let store = try HistoryStore(url: file)
        let space = UUID()
        let visits = (0..<count).map {
            HistoryVisit(space: space, url: URL(string: "https://example.com/article/\($0)")!, title: "Design systems research article \($0)", summary: "A synthetic description about typography, layouts and components.", time: now.addingTimeInterval(-Double($0 % 1000)), device: "audit", kind: .link)
        }
        try await store.merge(visits, now: now)
        var samples: [Double] = []
        for _ in 0..<3 {
            let t = DispatchTime.now().uptimeNanoseconds
            try await store.prune(keeping: .forever, now: now)
            samples.append(ms(t))
        }
        emit("prune \(count) pages median n3", samples.sorted()[1])
        for query in ["", "de", "design"] {
            var samples: [Double] = []
            for _ in 0..<7 {
                let t = DispatchTime.now().uptimeNanoseconds
                let rows = try await store.search(space: space, query: HistoryQuery(words: query), limit: 12)
                precondition(rows.count == 12)
                samples.append(ms(t))
            }
            emit("search \(count) '\(query)' median n7", samples.sorted()[3])
        }
    }
}
