import Foundation
import PadCore

func extensionScan() {
    let unit = "(()=>{const x=1;return x+2;})();\n"
    for size in [4096, 262144, 1048576] {
        let source = String(repeating: unit, count: size / unit.utf8.count)
        var times: [Double] = []
        for _ in 0..<3 {
            let start = DispatchTime.now().uptimeNanoseconds
            let result = ExtensionScan.uses(in: source, file: "fixture.js", of: [])
            precondition(result.isEmpty)
            times.append(ms(start))
        }
        emit("ExtensionScan \(source.utf8.count) bytes, empty missing set, median n3", times.sorted()[1])
    }
}
